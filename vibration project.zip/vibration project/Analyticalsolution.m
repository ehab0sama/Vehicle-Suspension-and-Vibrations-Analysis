%% DESCRIPTION
%
% This is a Script to solve the differential equation of a free double mass 
% system.
%
%% OUTPUT
%
% Formatted figure of the displacement of a single mass system and its
% animation.
%
%% VERSION
%             author: Kamal Emadeldin Kamal 
%      creation date: 22-December-2025
%     Matlab version: R2020a
%
%% REVISION
%
% V1.0 | 22-December-2025 | Kamal Emadeldin | creation
% 
%
%% Program
clear                                             % Delete Workspace
clc                                               % Clear Command Window
close all                                         % Close all figures

%% 1.) Definitions
%% 1.) -Parameter definition
l           = 0.56;                 % Rod length [m]
m_bar       = 0.55;                 % Mass of the bar 'm' [kg]
m1          = 0.25;               % Mass of block A [kg]
m2          = m1 * 2;           % Mass of block B [kg]
K           = 163.5;               % Stiffness of each spring [N/m]
C           = 17.46;                % Damping of each damper [Ns/m]
time        = 0:0.01:15;           % Time [s]

% Mass/Inertia Terms
J           = (1/12) * m_bar * l^2;         % Rod inertia about center
Jeq         = J + m1*(l/2)^2 + m2*(l/2)^2;  % Total equivalent inertia
Meq         = Jeq;                          % For a rotational system, Meq is Jeq

% Stiffness and Damping Terms (Torque per unit angle/angular velocity)
Keq         = K*(l/2)^2 + K*(l/2)^2;        % Equivalent torsional stiffness
Ceq         = C*(l/2)^2 + C*(l/2)^2;        % Equivalent torsional damping

% Initial Conditions 
phi_0       = deg2rad(5);          
phi_dot_0   = 0;
%% 2.) Computing
% Characteristic Equation: Jeq*s^2 + Ceq*s + Keq = 0
wn = sqrt(Keq/Jeq);                   % Natural frequency
zeta = Ceq / (2 * sqrt(Keq * Jeq));   % Damping ratio
wd = wn * sqrt(1 - zeta^2);           % Damped natural frequency

% Solution for underdamped free vibration (analytically):
% phi(t) = exp(-zeta*wn*t) * (A*cos(wd*t) + B*sin(wd*t))
A = phi_0;
B = (phi_dot_0 + zeta * wn * phi_0) / wd;

phi_t = exp(-zeta * wn * time) .* (A * cos(wd * time) + B * sin(wd * time));

% TRANSLATION TO BLOCK DISPLACEMENT
x1_t = (l/2) * phi_t;    % Displacement of Block 1 (Left)
x2_t = -(l/2) * phi_t;   % Displacement of Block 2 (Right) - opposite direction
%% Plotting the results
figure('Name', 'System Response Analysis', 'Color', 'w');

% Top Plot: Pitch Motion (Angular)
subplot(2,1,1)
plot(time, rad2deg(phi_t), 'r', 'LineWidth', 1.5)
grid on
ylabel('Pitch Angle \theta [deg]')
title('Pitch Motion of the Rod')

% Bottom Plot: Block Displacements (Linear)
subplot(2,1,2)
plot(time, x1_t, 'b', 'LineWidth', 1.5, 'DisplayName', 'Block 1 (m1)')
hold on
plot(time, x2_t, 'g', 'LineWidth', 1.5, 'DisplayName', 'Block 2 (m2)')
grid on
xlabel('Time [s]')
ylabel('Displacement [m]')
title('Linear Motion of the Blocks')
legend('Location', 'northeast')
sgtitle(['System Dynamics: \zeta = ', num2str(zeta, 3)])