%% DESCRIPTION
%
% This is a Script to solve the differential equation of a free double mass 
% system.
%
%% OUTPUT
%
% Formatted figure of the displacement of a single mass system and its
% animation.
%
%% VERSION
%             author: Kamal Emadeldin Kamal 
%      creation date: 22-December-2025
%     Matlab version: R2020a
%
%% REVISION
%
% V1.0 | 22-December-2025 | Kamal Emadeldin | creation
% 
%
%% Program
clear                                             % Delete Workspace
clc                                               % Clear Command Window
close all                                         % Close all figures
%% 1.) Definitions
l      = 0.6;          % Rod length [m]
m      = 1;            % Base mass [kg]
m1     = m;            % Mass of body 1
m2     = m*2;          % Mass of body 2
k      = 130;          % Spring stiffness [N/m]
c      = 2;            % Damping coefficient [Ns/m]
time   = 0:0.01:10;    % Time span [s]

% Equivalent Parameters (Angular/Pitch)
% Jeq = (1/12)mL^2 + m(L/2)^2 + 2m(L/2)^2 = (5/6)mL^2
Jeq = (5/6) * m * l^2; 

% Keq = k(L/2)^2 + k(L/2)^2 = (1/2)kL^2
Keq = (1/2) * k * l^2;

% Ceq = c(L/2)^2 + c(L/2)^2 = (1/2)cL^2
Ceq = (1/2) * c * l^2;

% Initial Conditions
phi_0     = deg2rad(10); 
phi_dot_0 = 0;           % zero initial velocity
w0        = [phi_0; phi_dot_0];

%% 2.) Solving with ODE45
% Call the solver
[t, w] = ode45(@(t, w) state_space_representation(t, w, Jeq, Ceq, Keq), time, w0);

% Extract Pitch and Block Displacement
phi_t = w(:, 1);
x1_t  = (l/2) * phi_t;
x2_t  = -(l/2) * phi_t;

%% 3.) Plotting
figure('Color', 'w', 'Name', 'ODE45 State-Space Solution');

% Subplot 1: Pitch Angle
subplot(2,1,1)
plot(t, rad2deg(phi_t), 'r', 'LineWidth', 1.5)
grid on; ylabel('Pitch \theta [deg]');
title('Pitch Motion (Angular)');

% Subplot 2: Mass Displacements
subplot(2,1,2)
plot(t, x1_t, 'b', 'LineWidth', 1.5, 'DisplayName', 'Mass 1'); hold on;
plot(t, x2_t, 'g', 'LineWidth', 1.5, 'DisplayName', 'Mass 2');
grid on; xlabel('Time [s]'); ylabel('Displacement [m]');
title('Linear Motion of Masses');
legend;

