%% DESCRIPTION
%
% This is a Script to solve the differential equation of a free double mass 
% system.
%
%% OUTPUT
%
% Formatted figure of the displacement of a single mass system and its
% animation.
%
%% VERSION
%             author: Kamal Emadeldin Kamal 
%      creation date: 22-December-2025
%     Matlab version: R2020a
%
%% REVISION
%
% V1.0 | 22-December-2025 | Kamal Emadeldin | creation
% 
%
%% Program
clear                                             % Delete Workspace
clc                                               % Clear Command Window
close all                                         % Close all figures
%% 1.) Definitions
l      = 0.6;          % Rod length [m]
m      = 1;            % Base mass [kg]
m1     = m;            % Mass of body 1
m2     = m*2;          % Mass of body 2
k      = 130;          % Spring stiffness [N/m]
c      = 2;            % Damping coefficient [Ns/m]
time   = 0:0.01:10;    % Time span [s]

% Equivalent Parameters (Angular/Pitch)
% Jeq = (1/12)mL^2 + m(L/2)^2 + 2m(L/2)^2 = (5/6)mL^2
Jeq = (5/6) * m * l^2; 

% Keq = k(L/2)^2 + k(L/2)^2 = (1/2)kL^2
Keq = (1/2) * k * l^2;

% Ceq = c(L/2)^2 + c(L/2)^2 = (1/2)cL^2
Ceq = (1/2) * c * l^2;

% Initial Conditions
phi_0     = deg2rad(10); 
phi_dot_0 = 0;           % zero initial velocity

%% 2.) Computing.
syms phi(t)
Dphi = diff(phi,1);
D2phi = diff(phi,2);

phi = dsolve(Jeq*D2phi + Ceq*Dphi + Keq*phi ==  0,phi(0) == phi_0, Dphi(0) == phi_dot_0,'t');

%% 2.) -Evaluating the equation 
phi_fun = matlabFunction(phi);
phi_dot_fun = matlabFunction(diff(phi));

phi_t = feval(phi_fun,time);
phi_dot_t = feval(phi_dot_fun,time);

%% 3.) Post-Processing
% Calculate linear displacements of the masses from the angular results
% Mass 1 is at L/2, Mass 2 is at -L/2
x1_t = (l/2) * phi_t;
x2_t = -(l/2) * phi_t;

%% 4.) Plotting
figure('Name', 'System Response - Symbolic Solution', 'Color', 'w');

% Subplot 1: Pitch Angle (theta)
subplot(2,1,1)
plot(time, rad2deg(phi_t), 'r', 'LineWidth', 1.5)
grid on
ylabel('Pitch Angle \theta [deg]')
title('Pitch Motion of the Rod (Rotational)')

% Subplot 2: Mass Displacements
subplot(2,1,2)
plot(time, x1_t, 'b', 'LineWidth', 1.5, 'DisplayName', 'Mass 1 (Left)')
hold on
plot(time, x2_t, 'g', 'LineWidth', 1.5, 'DisplayName', 'Mass 2 (Right)')
grid on
xlabel('Time [s]')
ylabel('Displacement [m]')
title('Linear Motion of the Masses')
legend('Location', 'best')

% Add a centered main title (Super Title)
sgtitle(['Free Vibration Analysis: \omega_n = ', num2str(sqrt(Keq/Jeq), '%.2f'), ' rad/s'])