function dw = state_space_representation(t, w, Jeq, Ceq, Keq)
    A = [0 1;-Keq/Jeq -Ceq/Jeq];
    dw = A*w;
end